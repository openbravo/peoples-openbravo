Tradu��o pt_BR realizada por Vipware Inform�tica Ltda.
http://www.vipware.com.br

To install this language pack follow these instructions:http://wiki.openbravo.com/wiki/index.php/Translating_Openbravo#Installing_a_new_translation


