/*
 *************************************************************************
 * The contents of this file are subject to the Openbravo  Public  License
 * Version  1.1  (the  "License"),  being   the  Mozilla   Public  License
 * Version 1.1  with a permitted attribution clause; you may not  use. this
 * file except in compliance with the License. You  may  obtain  a copy of
 * the License at http://www.openbravo.com/legal/license.html
 * Software distributed under the License  is  distributed  on  an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific  language  governing  rights  and  limitations
 * under the License.
 * The Original Code is Openbravo ERP.
 * The Initial Developer of the Original Code is Openbravo SLU
 * All portions are Copyright (C) 2011 Openbravo SLU
 * All Rights Reserved.
 * Contributor(s):  ______________________________________.
 ************************************************************************
 */

isc.ClassFactory.defineClass('OBUIWS_View', isc.VLayout);
isc.OBUIWS_View.addProperties({
  // Allow only one instance of the view.
  isSameTab: function(viewId, params){
    return viewId === 'OBUIWS_View';
  },
  getBookMarkParams: function() {
    var result = {};
    result.viewId = 'OBUIWS_View';
    return result;
  },
  
  initWidget: function(){
    
    OB.Datasource.get('Order', this);     

    this.Super('initWidget', arguments);
  },
  
  setDataSource: function(ds) {
    var grid = isc.OBGrid.create({
      selectionAppearance: 'checkbox',
      filterOnKeypress: true,
      dataSource: ds,
      autoFetchData: true,
      showFilterEditor: true,
      fields: [{name: 'documentNo'}, {name: 'orderDate'}, {name: 'actionBtn', width: '20%', cellAlign: 'center', showTitle: false, isButtonField: true}],
      
      createRecordComponent: function(record, colNum){
        var field = this.getField(colNum);
        if (field.isButtonField) {
          var component = isc.OBFormButton.create({
            title: 'Process Record',
            click: function() {
              isc.say("Clicked on record " + record._identifier);
            }
          });
          component.record = record;
          return component;
        }
        return null;
      },
      
      updateRecordComponent: function(record, colNum, component, recordChanged){
        var field = this.getField(colNum);
        if (field.isButtonField) {
          component.record = record;
          return component;
        }
      }
      
    });
    var processButton = isc.OBFormButton.create({
      title: 'Process Selected Orders',
      grid: grid,
      click: function() {
        isc.say(this.grid.getSelection().length + " records selected!");
      }      
    });
    grid.processButton = processButton;
    
    this.addMember(isc.LayoutSpacer.create({height: 20}));
    this.addMember(processButton);
    this.addMember(isc.LayoutSpacer.create({height: 20}));
    this.addMember(grid);    
  }
});